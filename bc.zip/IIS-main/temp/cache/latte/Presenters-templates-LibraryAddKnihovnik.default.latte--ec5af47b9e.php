<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/LibraryModule/Presenters/templates/LibraryAddKnihovnik.default.latte */
final class Templateec5af47b9e extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		if (!$this->getReferringTemplate() || $this->getReferenceType() === "extends") {
			foreach (array_intersect_key(['knihovnik' => '14'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="library-addk">
	<div id="library-addk-back">
		<a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link(":Library:Library:", [$libName])) /* line 4 */;
		echo '">Zpět</a>
	</div>
	<h1>Knihovníci knihovny: ';
		echo LR\Filters::escapeHtmlText($libName) /* line 6 */;
		echo '</h1>
	<table id="library-addk-table">
	<tr>
		<th>Jméno</th>
		<th>Přijmení</th>
		<th>Login</th>
		<th>Odstranit</th>
	</tr>
';
		$iterations = 0;
		foreach ($knihovniks as $knihovnik) /* line 14 */ {
			echo '		<tr>
			<td>';
			echo LR\Filters::escapeHtmlText($knihovnik->meno) /* line 16 */;
			echo ' </td>
			<td>';
			echo LR\Filters::escapeHtmlText($knihovnik->priezvisko) /* line 17 */;
			echo ' </td>
			<td>';
			echo LR\Filters::escapeHtmlText($knihovnik->ID) /* line 18 */;
			echo '</td>
			<td><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("deleteKnihovnik!", [$libName,$knihovnik->ID])) /* line 19 */;
			echo '">Zbavit zprávy</a></td>
		</tr>
';
			$iterations++;
		}
		echo '	</table>
    <div class="medzera"></div>
    <div class="medzera"></div>
    <div class="medzera"></div>
	<div id="library-addk-formular">
';
		/* line 27 */ $_tmp = $this->global->uiControl->getComponent("addKnihovnikForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '	</div>
</div>
';
	}

}
