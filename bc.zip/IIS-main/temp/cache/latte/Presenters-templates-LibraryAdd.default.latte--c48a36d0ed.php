<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/LibraryModule/Presenters/templates/LibraryAdd.default.latte */
final class Templatec48a36d0ed extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="library-add">
	<div id="library-add-back">
		<a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link(":Library:LibraryDashBoard:")) /* line 4 */;
		echo '">zpet</a>
	</div>
	<h1>Přidat knihovnu</h1>
	<div id="library-add-formular">
';
		/* line 8 */ $_tmp = $this->global->uiControl->getComponent("libraryAddForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '	</div>
</div>
';
	}

}
