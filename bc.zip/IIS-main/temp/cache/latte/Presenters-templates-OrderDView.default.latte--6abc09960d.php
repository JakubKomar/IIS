<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/OrderModule/Presenters/templates/OrderDView.default.latte */
final class Template6abc09960d extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		if (!$this->getReferringTemplate() || $this->getReferenceType() === "extends") {
			foreach (array_intersect_key(['order' => '12'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="ordersd">
    <h1>Objednávky ke zpracování</h1>
    <div class="medzera"></div>
    <table id="ordersd-table">
    <tr>
        <th>ID</th>
        <th>Stav</th>
        <th>Datum přijmutí</th>
        <th>Podrobnosti</th>
    </tr>
';
		$iterations = 0;
		foreach ($orders as $order) /* line 12 */ {
			echo '        <tr>
            <td>';
			echo LR\Filters::escapeHtmlText($order->ID) /* line 14 */;
			echo '</td>
            <td>';
			echo LR\Filters::escapeHtmlText($order->stav) /* line 15 */;
			echo '</td>
            <td>';
			echo LR\Filters::escapeHtmlText($order->datum_podani) /* line 16 */;
			echo '</td>
            <td><a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Order:", [$order->ID])) /* line 17 */;
			echo '">Podrobnosti</a></td>
        </tr>
';
			$iterations++;
		}
		echo '    </table>
</div>
';
	}

}
