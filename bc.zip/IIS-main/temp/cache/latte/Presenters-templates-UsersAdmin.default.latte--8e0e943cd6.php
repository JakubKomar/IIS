<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/AdminModule/Presenters/templates/UsersAdmin.default.latte */
final class Template8e0e943cd6 extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		if (!$this->getReferringTemplate() || $this->getReferenceType() === "extends") {
			foreach (array_intersect_key(['uzivatel' => '16'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="user-admin">
	<h1>Správa uživatelů</h1>
	<div id="user-admin-back">
		<a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("UserAdmCreate:")) /* line 5 */;
		echo '">Vytvořit nového uživatele</a>
	</div>
';
		if ($users) /* line 7 */ {
			echo '		<table id="user-admin-table">
		<tr>
			<th>ID</th>
			<th>Role</th>
			<th>Jméno</th>
			<th>Přijmení</th>
			<th>Editovat</th>
		</tr>
';
			$iterations = 0;
			foreach ($users as $uzivatel) /* line 16 */ {
				echo '			<tr>
				<div class="userItem">
					<td>';
				echo LR\Filters::escapeHtmlText($uzivatel->ID) /* line 19 */;
				echo '</td>
					<td>';
				echo LR\Filters::escapeHtmlText($uzivatel->role) /* line 20 */;
				echo '</td>
					<td>';
				echo LR\Filters::escapeHtmlText($uzivatel->meno) /* line 21 */;
				echo '</td>
					<td>';
				echo LR\Filters::escapeHtmlText($uzivatel->priezvisko) /* line 22 */;
				echo '</td>
					<td><a href="';
				echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("UserAdmEdit:", [$uzivatel->ID])) /* line 23 */;
				echo '">Editovat</a></td>
				</div>
			</tr>
';
				$iterations++;
			}
			echo '		</table>
';
		}
		echo '</div>
';
	}

}
