<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/BookTransactionModule/Presenters/templates/LibBookManualEdit.default.latte */
final class Templatebdd3c3fb96 extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="lib-books-manual-edit">
    <div id="lib-books-manual-edit-back">
        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("LibBooks:", [$poskytuje->ID_knihovna])) /* line 4 */;
		echo '">Zpět</a>
    </div>
    <h1>Editovat počet titulů: "';
		echo LR\Filters::escapeHtmlText($poskytuje->ID_titul) /* line 6 */;
		echo '" v knihovně: ';
		echo LR\Filters::escapeHtmlText($poskytuje->ID_knihovna) /* line 6 */;
		echo ' </h1>
    <p>Varování: záznam se odstraní po návratu všech knih</p>
    <div id="lib-books-manual-edit-formular">
';
		/* line 9 */ $_tmp = $this->global->uiControl->getComponent("bookEditForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '    </div>
</div>
';
	}

}
