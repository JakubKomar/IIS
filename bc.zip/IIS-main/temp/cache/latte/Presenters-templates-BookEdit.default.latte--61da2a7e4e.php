<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/BookModule/Presenters/templates/BookEdit.default.latte */
final class Template61da2a7e4e extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		if (!$this->getReferringTemplate() || $this->getReferenceType() === "extends") {
			foreach (array_intersect_key(['autor' => '16'], $this->params) as $ʟ_v => $ʟ_l) {
				trigger_error("Variable \$$ʟ_v overwritten in foreach on line $ʟ_l");
			}
		}
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="book-edit">
    <div id="book-edit-back">
        <a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("Kniha:show", [$bookData->ID])) /* line 4 */;
		echo '">Zpět na náhled</a>
        </div>
    <h1>Editace knihy: ';
		echo LR\Filters::escapeHtmlText($bookData->ID) /* line 6 */;
		echo '</h1>
    <div id="book-edit-formular-1">
';
		/* line 8 */ $_tmp = $this->global->uiControl->getComponent("bookEditForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '    </div>
    <div class="medzera"></div>
    <h2>Autoři:</h2>
    <div id="book-edit-formular-2">
';
		/* line 13 */ $_tmp = $this->global->uiControl->getComponent("autorCreateForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '    </div>
    <ul>
';
		$iterations = 0;
		foreach ($autori as $autor) /* line 16 */ {
			echo '        <div class="autor">
            <li>';
			echo LR\Filters::escapeHtmlText($autor->meno) /* line 18 */;
			echo ' ';
			echo LR\Filters::escapeHtmlText($autor->priezvisko) /* line 18 */;
			echo ' <a href="';
			echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link("deleteAutor!", [$autor->ID_titul,$autor->diskriminant])) /* line 18 */;
			echo '">Vymazat</a></li>
        </div>
';
			$iterations++;
		}
		echo '    </ul>
</div>
';
	}

}
