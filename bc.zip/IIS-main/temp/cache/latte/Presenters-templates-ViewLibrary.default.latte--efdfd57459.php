<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/LibraryModule/Presenters/templates/ViewLibrary.default.latte */
final class Templateefdfd57459 extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="library-view">
	<a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link(":Library:ViewLibraries:")) /* line 3 */;
		echo '">Zpět</a>
	<h1>Knihovna: ';
		echo LR\Filters::escapeHtmlText($knihovna->ID) /* line 4 */;
		echo '</h1>
	<p>';
		echo LR\Filters::escapeHtmlText($knihovna->popis) /* line 5 */;
		echo '</p>
	<div class="medzera"></div>
	<h2>Otevírací doba</h2>
	<p>';
		echo LR\Filters::escapeHtmlText($knihovna->oteviraci_doba) /* line 8 */;
		echo '</p>
	<div class="medzera"></div>
	<h2>Adresa</h2>
	<p>';
		echo LR\Filters::escapeHtmlText($knihovna->adresa) /* line 11 */;
		echo '</p>
</div>
';
	}

}
