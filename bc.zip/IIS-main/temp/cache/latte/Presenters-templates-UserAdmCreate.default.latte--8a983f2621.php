<?php

use Latte\Runtime as LR;

/** source: /var/www/html/IIS-main/app/AdminModule/Presenters/templates/UserAdmCreate.default.latte */
final class Template8a983f2621 extends Latte\Runtime\Template
{
	protected const BLOCKS = [
		['content' => 'blockContent'],
	];


	public function main(): array
	{
		extract($this->params);
		if ($this->getParentName()) {
			return get_defined_vars();
		}
		$this->renderBlock('content', get_defined_vars()) /* line 1 */;
		return get_defined_vars();
	}


	public function prepare(): void
	{
		extract($this->params);
		Nette\Bridges\ApplicationLatte\UIRuntime::initialize($this, $this->parentName, $this->blocks);
		
	}


	/** {block content} on line 1 */
	public function blockContent(array $ʟ_args): void
	{
		extract($this->params);
		extract($ʟ_args);
		unset($ʟ_args);
		echo '<div id="user-admin-create">
	<div id="user-admin-create-back">
		<a href="';
		echo LR\Filters::escapeHtmlAttr($this->global->uiControl->link(":Admin:UsersAdmin:")) /* line 4 */;
		echo '">Zpět</a>
	</div>
	<h1>Vytváření uživatele</h1>
	<div id="user-admin-create-formular">
';
		/* line 8 */ $_tmp = $this->global->uiControl->getComponent("admCreateProfileForm");
		if ($_tmp instanceof Nette\Application\UI\Renderable) $_tmp->redrawControl(null, false);
		$_tmp->render();
		echo '	</div>
</div>
';
	}

}
