<?php

declare(strict_types=1);

namespace App\CoreModule\Presenters;

use Nette;


final class HomepagePresenter extends  \App\CoreModule\Presenters\BasePresenter
{
	public function __construct()
	{
	}
	public function renderDefault(): void
	{

	}
}
